package collections.java8;

import java.util.Arrays;
import java.util.Collection;

import collections.operations.MyClass;

public class RetrieveCollection {

	public static void main(String[] args) {
		MyClass[] myArray = {
				new MyClass("val1", "abc"), 
				new MyClass("val2", "xyz"),
				new MyClass("val3", "abc") 
				};

		Collection<MyClass> list = Arrays.asList(myArray);

		list.forEach(c -> System.out.println(c.getLabel()));

	}

}
