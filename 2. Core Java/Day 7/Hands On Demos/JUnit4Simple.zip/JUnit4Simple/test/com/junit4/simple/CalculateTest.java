package com.junit4.simple;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculateTest {

	Calculate calculation = new Calculate();
	int sum = calculation.sum(2, 5);
	int testSum = 7;

	@Test
	public void testSum() {

		System.out.println(" @TestSum sum:" + sum + " = " + testSum);
		assertEquals(sum, testSum);

	}

}
