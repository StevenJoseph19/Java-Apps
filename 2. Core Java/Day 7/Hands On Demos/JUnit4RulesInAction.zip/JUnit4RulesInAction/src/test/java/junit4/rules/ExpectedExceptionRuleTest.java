package junit4.rules;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.isA;
import static org.junit.Assert.*;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;

@RunWith(BlockJUnit4ClassRunner.class)
public class ExpectedExceptionRuleTest {

	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	@Test
	public void whenExceptionOccursThenExpectException() {

		expectedException.expect(IllegalArgumentException.class);
		expectedException.expectCause(isA(ArithmeticException.class));
		expectedException.expectMessage(is("Divisor can't be null"));

		throw new IllegalArgumentException("Divisor can't be null", new ArithmeticException());

	}
}
