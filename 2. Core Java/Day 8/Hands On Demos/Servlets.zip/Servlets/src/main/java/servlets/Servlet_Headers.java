package servlets;

import java.io.IOException;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/headers")
public class Servlet_Headers extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Set content type
		response.setContentType("text/plain");
		// Determine Language to use
		Locale locale = request.getLocale();
		String languageTag = locale.toLanguageTag().substring(0, 2);

		// Determine Greeting Language
		String greeting;

		switch (languageTag) {
		case "fr":// French
			greeting = "BonJour ";
			break;

		case "de": // Germany
			greeting = "Guten Tag ";
			break;

		default:// anything else
			greeting = "Hello ";
			languageTag = "en";

		}

		String name = request.getParameter("name");

		if (name == null) {
			name = "";

		}

		response.getWriter().println(greeting +" "+ name);

		response.setHeader("Content-Language", languageTag);
	}

}
