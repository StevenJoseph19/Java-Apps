package com.mycompany.conferenceweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConferenceWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConferenceWebApplication.class, args);
	}

}
